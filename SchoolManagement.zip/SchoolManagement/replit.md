# Student Management System - Project Overview

## Overview

This is a Flask-based student management system designed for educational institutions. The application provides separate interfaces for teachers and students, allowing teachers to manage grades and assignments while students can view their academic progress. The system is built with a focus on simplicity and educational functionality.

## System Architecture

### Frontend Architecture
- **Template Engine**: Jinja2 templates with Flask
- **UI Framework**: Bootstrap 5 with dark theme support
- **Icons**: Font Awesome for consistent iconography
- **Styling**: Custom CSS with educational theme colors
- **Responsive Design**: Mobile-first approach using Bootstrap grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database ORM**: SQLAlchemy with Flask-SQLAlchemy extension
- **Authentication**: Session-based authentication with password hashing (Werkzeug)
- **Server**: Gunicorn WSGI server for production deployment
- **Environment**: Python 3.11 runtime

### Database Design
- **Primary Database**: SQLite for development (configurable to PostgreSQL via DATABASE_URL)
- **ORM Pattern**: SQLAlchemy DeclarativeBase with relationship mapping
- **Models**: User (students/teachers), Subject, Grade, Assignment entities
- **Authentication**: Password hashing with Werkzeug security utilities

## Key Components

### Core Models
1. **User Model**: Handles both students and teachers with role-based differentiation
   - Username/password authentication
   - Role-based access control (teacher/student)
   - Relationship mappings to grades and assignments

2. **Subject Model**: Represents academic subjects/courses
   - Basic subject information and descriptions
   - Linked to grades and assignments

3. **Grade Model**: Tracks student academic performance
   - Student-subject grade relationships
   - Exam type categorization (midterm, final, quiz)
   - Timestamped grade entries with optional notes

4. **Assignment Model**: Manages student assignments (incomplete implementation)
   - Student-subject assignment relationships
   - Assignment tracking and status management

### Application Structure
- **app.py**: Main application factory and configuration
- **main.py**: Application entry point for production
- **models.py**: Database model definitions
- **routes.py**: Route handlers and view logic (incomplete)
- **templates/**: Jinja2 template files for UI rendering
- **static/**: CSS and static asset files

## Data Flow

### Authentication Flow
1. User submits login credentials via POST to root route
2. System validates credentials against User model
3. Successful authentication establishes session with role information
4. Role-based redirect to appropriate dashboard (teacher/student)

### Teacher Workflow
1. Access teacher dashboard with system statistics
2. Manage student grades through dedicated interface
3. Create and track assignments for students
4. View recent activity and pending items

### Student Workflow
1. Access student dashboard with personal academic summary
2. View individual grades and academic performance
3. Track assignment status and deadlines
4. Monitor overall academic progress

## External Dependencies

### Python Packages
- **Flask 3.1.1**: Core web framework
- **Flask-SQLAlchemy 3.1.1**: Database ORM integration
- **SQLAlchemy 2.0.41**: Database abstraction layer
- **Werkzeug 3.1.3**: WSGI utilities and security functions
- **Gunicorn 23.0.0**: Production WSGI server
- **psycopg2-binary 2.9.10**: PostgreSQL database adapter
- **email-validator 2.2.0**: Email validation utilities

### Frontend Dependencies
- **Bootstrap 5**: CSS framework via CDN
- **Font Awesome 6.0.0**: Icon library via CDN
- **Custom CSS**: Educational theme styling

## Deployment Strategy

### Development Environment
- **Runtime**: Python 3.11 on Nix environment
- **Database**: SQLite with automatic table creation
- **Server**: Flask development server with debug mode
- **Hot Reload**: Automatic code reloading enabled

### Production Environment
- **Server**: Gunicorn with autoscale deployment target
- **Binding**: 0.0.0.0:5000 with port reuse optimization
- **Database**: Configurable via DATABASE_URL environment variable
- **Session Security**: Configurable session secret key
- **Proxy Support**: ProxyFix middleware for reverse proxy compatibility

### Environment Configuration
- **Database URL**: Defaults to SQLite, supports PostgreSQL
- **Session Secret**: Environment-configurable for security
- **Connection Pooling**: Configured for database connection management
- **Logging**: Debug-level logging enabled for development

## Project Status
**COMPLETED** - Student Management System fully implemented and ready for deployment.

## Final Features
- ✓ Teacher authentication system (username: deryam, password: 1234)
- ✓ Complete student account management (create, view, delete)
- ✓ Grade management with full CRUD operations
- ✓ Assignment system with PDF file upload/download
- ✓ Role-based dashboards for teachers and students
- ✓ Historical data views with pagination
- ✓ Responsive Bootstrap UI with dark theme
- ✓ Secure file handling and data validation

## Recent Changes
- June 24, 2025: **PROJECT COMPLETED** - Updated teacher username to "deryaci"
- June 24, 2025: Added student management system for teachers to create new student accounts
- June 24, 2025: Reversed file upload - teachers now upload assignment files, students download them
- June 24, 2025: Added file upload functionality for assignments
- June 24, 2025: Implemented delete functionality for grades and assignments  
- June 24, 2025: Created comprehensive historical views with pagination
- June 24, 2025: Enhanced navigation with history dropdown menu
- June 24, 2025: Initial system setup with authentication and dashboards

## Changelog
- June 24, 2025. Initial setup
- June 24, 2025. Added assignment file upload system
- June 24, 2025. Added delete and historical view functionality

## User Preferences

Preferred communication style: Simple, everyday language.

## Notes

The application appears to be in early development with incomplete route implementations and missing Assignment model definition. The template files suggest a comprehensive UI design, but the backend routes need completion. The system is configured for both development and production deployment with appropriate database and server configurations.